"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Timeline from "./Timeline";
import {
  TRANSITION_LIST, transitionOf,
  MIN_TRANSITION_DURATION, MAX_TRANSITION_DURATION,
} from "../lib/transitions";
import {
  CAPTION_STYLE_LIST, CAPTION_SIZES, CAPTION_FONT_LIST, CAPTION_ANIM_LIST,
  captionAt, activeCue, wordIndexAt, wordFractionAt, appearProgress,
  drawCaption, captionFontPx, captionLineHeightDefault,
} from "../lib/captions";
import { LOGO_POSITION_LIST, drawLogo } from "../lib/watermark";
import { drawEffects } from "../lib/effects";
import { motionTransform, MOTION_LIST } from "../lib/motion";
import { EXPORT_PRESETS, matchPreset } from "../lib/exportPresets";

function tc(t) {
  if (!isFinite(t) || t < 0) t = 0;
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  const d = Math.floor((t * 10) % 10);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${d}`;
}

function clock(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

export default function Editor({
  clips, imageEls, audioUrl, duration, peaks, dims,
  aspect, setAspect, fps, setFps,
  renderQuality = "full", setRenderQuality, renderDims,
  onRender, onCancel, busy, progress, outUrl, error, warnings,
  onWebCodecsTest, onWebCodecsCancel, wcBusy, wcProgress, wcPhase, wcAvailable, serverAvailable, wcEnabled, setWcEnabled,
  replaceImage, removeImage, fillGap, resizeBoundary,
  transitionsByName, transitionDuration, setTransition, applyTransitionAll, applyTransitionMix, setTransitionDuration,
  fadeIn, setFadeIn, fadeOut, setFadeOut,
  motionByName, setMotion, applyMotionAll, applyMotionAlternate, motionAmount, setMotionAmount,
  videoInfoByName = {}, trimByName = {}, setTrim, volumeByName = {}, setVolume,
  fitByName = {}, setFit,
  trimEnd, setTrimEnd, exportDuration,
  undo, redo, canUndo, canRedo,
  captionCues, captionsOn, setCaptionsOn, captionStyle, setCaptionStyle,
  captionSize, setCaptionSize, captionLineHeight, setCaptionLineHeight,
  captionFontScale, setCaptionFontScale,
  captionFont = "default", setCaptionFont,
  captionAnim = "none", setCaptionAnim,
  vignette = 0, setVignette, grain = 0, setGrain, leaks = 0, setLeaks,
  captionName, captionError, onCaptionFile,
  logoFile, logoImg, onLogo, clearLogo,
  logoPosition = "br", setLogoPosition,
  logoSize = 0.14, setLogoSize,
  logoOpacity = 0.9, setLogoOpacity,
  musicFile, onMusic, clearMusic,
  musicVolume = 0.15, setMusicVolume, musicDuck = true, setMusicDuck,
}) {
  const canvasRef = useRef(null);
  const audioRef = useRef(null);
  const musicRef = useRef(null);
  const rafRef = useRef(0);
  const fileInputRef = useRef(null);
  const capInputRef = useRef(null);
  const musicInputRef = useRef(null);
  const logoInputRef = useRef(null);
  const replaceInputRef = useRef(null);
  const pending = useRef(null); // gap-fill target name
  const trimEndRef = useRef(exportDuration);
  const vidRefs = useRef({});     // clip name -> offscreen <video> for live preview
  const drawRef = useRef(null);   // latest draw fn (so video 'seeked' can redraw)
  const timeRef = useRef(0);      // latest playhead time
  const modalVideoRef = useRef(null); // the trim scrubber <video> in the inspector
  useEffect(() => { trimEndRef.current = exportDuration; }, [exportDuration]);
  const [time, setTime] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [elapsed, setElapsed] = useState(0); // seconds spent in the current render
  const [selectedCut, setSelectedCut] = useState(null); // selected clip name (drives transition)
  const [currentType, setCurrentType] = useState("fade");
  const [inspect, setInspect] = useState(null);   // slot name open in the inspector
  const [dismissedWarn, setDismissedWarn] = useState(() => new Set()); // hidden warning texts
  // On touch devices, accept="image/*"/"video/*" makes Android open Google Photos,
  // which renames files and breaks the timestamp. Dropping accept opens the Files
  // picker instead (keeps 0-04.mp4). onPick* still filter by type, so nothing bad
  // gets through. Same trick as Dropzone.
  const [coarse, setCoarse] = useState(false);
  useEffect(() => {
    try { setCoarse(window.matchMedia && window.matchMedia("(pointer: coarse)").matches); } catch { /* ignore */ }
  }, []);
  // Object URL for the music file, so the preview can play it live (in sync with
  // the voiceover). Revoked whenever the file changes / unmounts.
  const [musicUrl, setMusicUrl] = useState(null);
  useEffect(() => {
    if (!musicFile) { setMusicUrl(null); return; }
    const url = URL.createObjectURL(musicFile);
    setMusicUrl(url);
    return () => { try { URL.revokeObjectURL(url); } catch (_) {} };
  }, [musicFile]);
  const [pendFile, setPendFile] = useState(null);  // chosen replacement, not yet applied
  const [pendUrl, setPendUrl] = useState(null);
  const [mixMode, setMixMode] = useState(false); // Transitions panel in random-mix mode
  const [mixPicks, setMixPicks] = useState(() => new Set()); // ephemeral: chosen transitions for the random mix
  const toggleMix = useCallback((id) => {
    setMixPicks((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  // Gap "+" → pick a file to fill an empty slot / lead-in.
  const askAdd = useCallback((name) => {
    pending.current = name;
    if (fileInputRef.current) fileInputRef.current.click();
  }, []);

  const onPickFile = useCallback((e) => {
    const file = e.target.files && e.target.files[0];
    if (file && pending.current && fillGap) fillGap(pending.current, file);
    e.target.value = "";
    pending.current = null;
  }, [fillGap]);

  // Clip inspector: click a clip → preview → optionally pick a replacement,
  // preview it, then Apply (or Remove the image).
  const clearPend = useCallback(() => {
    setPendUrl((u) => { if (u) URL.revokeObjectURL(u); return null; });
    setPendFile(null);
  }, []);
  const openInspect = useCallback((name) => { clearPend(); setInspect(name); }, [clearPend]);
  const closeInspect = useCallback(() => { clearPend(); setInspect(null); }, [clearPend]);
  const onPickReplacement = useCallback((e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file || !(file.type.startsWith("image/") || file.type.startsWith("video/"))) return;
    setPendFile(file);
    setPendUrl((u) => { if (u) URL.revokeObjectURL(u); return URL.createObjectURL(file); });
  }, []);
  const applyReplacement = useCallback(() => {
    if (inspect && pendFile && replaceImage) replaceImage(inspect, pendFile);
    closeInspect();
  }, [inspect, pendFile, replaceImage, closeInspect]);
  const removeInspected = useCallback(() => {
    if (inspect && removeImage) removeImage(inspect);
    closeInspect();
  }, [inspect, removeImage, closeInspect]);

  useEffect(() => {
    if (!inspect) return;
    const onEsc = (e) => { if (e.key === "Escape") closeInspect(); };
    window.addEventListener("keydown", onEsc);
    return () => window.removeEventListener("keydown", onEsc);
  }, [inspect, closeInspect]);

  const onPickCaption = useCallback((e) => {
    const file = e.target.files && e.target.files[0];
    if (file && onCaptionFile) onCaptionFile(file);
    e.target.value = "";
  }, [onCaptionFile]);

  const onPickMusic = useCallback((e) => {
    const file = e.target.files && e.target.files[0];
    if (file && onMusic) onMusic([file]);
    e.target.value = "";
  }, [onMusic]);

  const onPickLogo = useCallback((e) => {
    const file = e.target.files && e.target.files[0];
    if (file && onLogo) onLogo([file]);
    e.target.value = "";
  }, [onLogo]);

  // Keep one offscreen <video> per video clip so the preview can draw live frames
  // (not just the poster). Created/torn down as clips come and go.
  useEffect(() => {
    const map = vidRefs.current;
    for (const [name, info] of Object.entries(videoInfoByName)) {
      if (!map[name] && info && info.url) {
        const v = document.createElement("video");
        v.src = info.url; v.muted = true; v.playsInline = true; v.preload = "auto";
        const redraw = () => { if (drawRef.current) drawRef.current(timeRef.current); };
        v.addEventListener("seeked", redraw);
        v.addEventListener("loadeddata", redraw);
        map[name] = v;
      }
    }
    for (const name of Object.keys(map)) {
      if (!videoInfoByName[name]) { try { map[name].pause(); } catch { /* ignore */ } delete map[name]; }
    }
  }, [videoInfoByName]);

  // Where in the source video to show for a clip at playhead t: the trim in-point
  // plus elapsed × speed (fast-forward). Mirrors the render math in page.js.
  const videoParams = useCallback((name, slotDur) => {
    const info = videoInfoByName[name];
    if (!info) return null;
    const dur = info.duration || 0;
    // Default by length: longer-than-slot trims (1x), shorter fills the slot ("fit").
    const mode = fitByName[name] || (dur > slotDur ? "trim" : "fit");
    if (mode === "fit" && slotDur > 0 && dur > 0 && Math.abs(dur - slotDur) > 0.05) return { trimStart: 0, speed: dur / slotDur };
    return { trimStart: trimByName[name] || 0, speed: 1 };
  }, [videoInfoByName, fitByName, trimByName]);

  const draw = useCallback((t) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.width, H = canvas.height;
    ctx.globalAlpha = 1;
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, W, H);
    let activeVideo = null; // clip name whose video should be playing this frame

    // Per-clip Ken Burns zoom at time tt (gaps never zoom). Progress is clamped so
    // an outgoing image keeps its end-of-clip zoom through the transition.
    const motionAt = (ci, tt) => {
      const c = clips[ci];
      if (!c || c.gap) return { scale: 1, dx: 0, dy: 0 };
      const m = (motionByName && motionByName[c.name]) || "none";
      if (m === "none") return { scale: 1, dx: 0, dy: 0 };
      const lp = Math.min(1, Math.max(0, (tt - c.start) / c.duration));
      return motionTransform(m, lp, motionAmount, W, H, tt);
    };
    const scaleAt = (ci, tt) => motionAt(ci, tt).scale;

    // Start/keep a clip's offscreen <video> playing in sync with the playhead and
    // mark it active (so it isn't paused). Returns the element to draw, or null if
    // it isn't a ready-to-draw video. Called both while a clip is showing AND
    // during the transition INTO it, so the video is already warm when revealed.
    const primeVideo = (c, tt, wantDraw) => {
      const vinfo = videoInfoByName[c.name];
      if (!vinfo) return null;
      const v = vidRefs.current[c.name];
      const pr = videoParams(c.name, c.duration);
      if (!v || !pr) return null;
      const srcTime = Math.min(vinfo.duration || 0, Math.max(0, pr.trimStart + (tt - c.start) * pr.speed));
      const clipVol = volumeByName[c.name] == null ? 0.5 : volumeByName[c.name];
      v.volume = Math.min(1, Math.max(0, clipVol));
      v.muted = clipVol <= 0;
      v.playbackRate = Math.min(16, Math.max(0.0625, pr.speed));
      if (v.paused) { try { v.currentTime = srcTime; } catch { /* ignore */ } v.play().catch(() => {}); }
      else if (Math.abs(v.currentTime - srcTime) > 0.6) { try { v.currentTime = srcTime; } catch { /* ignore */ } }
      activeVideo = c.name;
      return (wantDraw && v.readyState >= 2 && !v.seeking) ? v : null;
    };

    if (clips.length) {
      let idx = clips.findIndex((c) => t >= c.start && t < c.start + c.duration);
      if (idx === -1) idx = clips.length - 1;
      const clip = clips[idx];
      const type = idx > 0 ? (transitionsByName[clip.name] || "cut") : "cut";
      const tdur = type === "cut" ? 0 : Math.min(transitionDuration, clip.duration);

      if (idx > 0 && tdur > 0 && t < clip.start + tdur) {
        // Inside a transition: blend the previous image into this one, each at
        // its own current zoom so nothing snaps back to normal size.
        const p = Math.min(1, Math.max(0, (t - clip.start) / tdur));
        transitionOf(type).canvas(
          ctx, imageEls[clips[idx - 1].name] || null, imageEls[clip.name] || null, p, W, H,
          scaleAt(idx - 1, t), scaleAt(idx, t)
        );
        ctx.globalAlpha = 1;
        // Warm up the incoming video during the transition so it's already
        // decoding/playing when it takes over — fixes the stall-then-smooth start.
        if (playing) primeVideo(clip, t, false);
      } else {
        // While PLAYING, draw live video frames (kept warm since the transition);
        // paused/scrubbing shows the still poster — seeking a paused, offscreen
        // video flashes black on many (mobile) browsers, so we don't seek it.
        let drawable = imageEls[clip.name];
        if (playing) { const vEl = primeVideo(clip, t, true); if (vEl) drawable = vEl; }
        const dw = (drawable && (drawable.videoWidth || drawable.naturalWidth)) || 0;
        const dh = (drawable && (drawable.videoHeight || drawable.naturalHeight)) || 0;
        if (drawable && dw && dh) {
          const mt = motionAt(idx, t);
          const scale = Math.min(W / dw, H / dh) * mt.scale;
          const w = dw * scale, h = dh * scale;
          ctx.drawImage(drawable, (W - w) / 2 + mt.dx, (H - h) / 2 + mt.dy, w, h);
        }
      }
    }

    // Only the clip under the playhead plays; pause every other clip's video.
    for (const [nm, v] of Object.entries(vidRefs.current)) {
      if (nm !== activeVideo && !v.paused) { try { v.pause(); } catch { /* ignore */ } }
    }

    // Cinematic overlays (vignette / grain / light leaks) on the imagery, under
    // the captions + logo so text stays crisp.
    if (vignette > 0 || grain > 0 || leaks > 0) drawEffects(ctx, W, H, t, { vignette, grain, leaks });

    // Captions burn in before the fades, so the fade dims them too.
    if (captionsOn && captionCues && captionCues.length) {
      const ac = activeCue(captionCues, t);
      if (ac && ac.text) {
        // For karaoke styles, work out which word is being spoken right now, plus
        // how far through it we are (drives the pop/bounce animation).
        const nWords = ac.text.trim().split(/\s+/).filter(Boolean).length;
        const activeWord = wordIndexAt(nWords, ac.progress);
        const wordFrac = wordFractionAt(nWords, ac.progress);
        const appear = appearProgress(ac, t);
        drawCaption(ctx, ac.text, W, H, captionStyle, captionFontPx(H, captionSize, captionFontScale),
          captionLineHeight, captionFont, activeWord, wordFrac, captionAnim, appear);
      }
    }

    // Logo / watermark on top of everything (before the fades, so fades dim it too).
    if (logoImg) drawLogo(ctx, logoImg, W, H, { position: logoPosition, size: logoSize, opacity: logoOpacity });

    // Scene fades (opening / ending).
    if (fadeIn > 0 && t < fadeIn) {
      ctx.globalAlpha = Math.max(0, 1 - t / fadeIn);
      ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1;
    }
    const outStart = exportDuration - fadeOut;
    if (fadeOut > 0 && t > outStart) {
      ctx.globalAlpha = Math.min(1, (t - outStart) / fadeOut);
      ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1;
    }
  }, [clips, imageEls, transitionsByName, transitionDuration, motionByName, motionAmount,
      fadeIn, fadeOut, duration, exportDuration, playing, videoInfoByName, videoParams, volumeByName,
      captionsOn, captionCues, captionStyle, captionSize, captionLineHeight, captionFontScale, captionFont, captionAnim,
      vignette, grain, leaks,
      logoImg, logoPosition, logoSize, logoOpacity]);

  useEffect(() => { drawRef.current = draw; }, [draw]);
  useEffect(() => { timeRef.current = time; }, [time]);
  useEffect(() => { draw(time); }, [time, draw]);
  useEffect(() => { setTime(0); }, [audioUrl]);

  // Elapsed render timer.
  useEffect(() => {
    if (!busy && !wcBusy) { setElapsed(0); return; }
    const start = Date.now();
    setElapsed(0);
    const id = setInterval(() => setElapsed((Date.now() - start) / 1000), 250);
    return () => clearInterval(id);
  }, [busy, wcBusy]);

  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    const loop = () => {
      const end = trimEndRef.current;
      if (end > 0 && a.currentTime >= end) {
        a.pause();
        a.currentTime = end;
        setTime(end);
        return;
      }
      setTime(a.currentTime);
      rafRef.current = requestAnimationFrame(loop);
    };
    const onPlay = () => { setPlaying(true); cancelAnimationFrame(rafRef.current); rafRef.current = requestAnimationFrame(loop); };
    const onStop = () => { setPlaying(false); cancelAnimationFrame(rafRef.current); setTime(a.currentTime); };
    a.addEventListener("play", onPlay);
    a.addEventListener("pause", onStop);
    a.addEventListener("ended", onStop);
    return () => {
      a.removeEventListener("play", onPlay);
      a.removeEventListener("pause", onStop);
      a.removeEventListener("ended", onStop);
      cancelAnimationFrame(rafRef.current);
    };
  }, [audioUrl]);

  const toggle = useCallback(() => {
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) a.play(); else a.pause();
  }, []);

  // Live background-music preview: mirror the voiceover element's play / pause /
  // seek onto a second <audio> so you hear the mix without rendering. This is a
  // close approximation — the exact loop seam + tail fade are applied at render
  // time — but the volume (and ducking) match the export. `loop` handles the
  // "music shorter than video" case; render does a seamless loop + fade-out.
  const effectiveMusicVol = musicVolume * ((musicDuck && audioUrl) ? 0.35 : 1);
  useEffect(() => {
    const m = musicRef.current;
    if (m) m.volume = Math.max(0, Math.min(1, effectiveMusicVol));
  }, [effectiveMusicVol, musicUrl]);
  useEffect(() => {
    const a = audioRef.current, m = musicRef.current;
    if (!a || !m || !musicUrl) return;
    const sync = () => { try { if (Math.abs(m.currentTime - a.currentTime) > 0.25) m.currentTime = a.currentTime % (m.duration || 1e9); } catch (_) {} };
    const onPlay = () => { sync(); m.play().catch(() => {}); };
    const onPause = () => { try { m.pause(); } catch (_) {} };
    const onSeeked = () => sync();
    a.addEventListener("play", onPlay);
    a.addEventListener("pause", onPause);
    a.addEventListener("ended", onPause);
    a.addEventListener("seeked", onSeeked);
    // If we mount mid-playback, get in step immediately.
    if (!a.paused) onPlay();
    return () => {
      a.removeEventListener("play", onPlay);
      a.removeEventListener("pause", onPause);
      a.removeEventListener("ended", onPause);
      a.removeEventListener("seeked", onSeeked);
      try { m.pause(); } catch (_) {}
    };
  }, [musicUrl, audioUrl]);

  // Coalesce rapid scrub seeks: while a seek is still settling (slow for WAV),
  // remember the latest target and apply it on 'seeked', so the drag's release
  // position always wins instead of being dropped mid-seek.
  const pendingSeekRef = useRef(null);
  const seek = useCallback((t) => {
    const a = audioRef.current;
    if (!a) return;
    const c = Math.min(Math.max(t, 0), duration || t || 0);
    setTime(c);
    if (a.seeking) pendingSeekRef.current = c;
    else { pendingSeekRef.current = null; try { a.currentTime = c; } catch (_) {} }
  }, [duration]);
  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    const onSeeked = () => {
      const p = pendingSeekRef.current;
      if (p != null) { pendingSeekRef.current = null; if (Math.abs(a.currentTime - p) > 0.02) { try { a.currentTime = p; } catch (_) {} } }
    };
    a.addEventListener("seeked", onSeeked);
    return () => a.removeEventListener("seeked", onSeeked);
  }, [audioUrl]);

  // Scrubbing a *playing* WAV backward doesn't take — the seek fights live
  // playback and the release position is lost (MP3 settles fast enough to hide
  // this). So pause on grab, let the drag seek freely, then resume from the
  // release point once the pointer is up.
  const scrubResumeRef = useRef(false);
  const onScrubStart = useCallback(() => {
    const a = audioRef.current;
    scrubResumeRef.current = !!(a && !a.paused);
    if (a && !a.paused) { try { a.pause(); } catch (_) {} }
  }, []);
  const onScrubEnd = useCallback(() => {
    const a = audioRef.current;
    if (a && scrubResumeRef.current) { scrubResumeRef.current = false; a.play().catch(() => {}); }
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      const tag = (e.target.tagName || "").toLowerCase();
      if (tag === "input" || tag === "select" || tag === "textarea") return;
      if (e.code === "Space") { e.preventDefault(); toggle(); }
      else if (e.code === "ArrowRight") { e.preventDefault(); seek(time + (e.shiftKey ? 5 : 1)); }
      else if (e.code === "ArrowLeft") { e.preventDefault(); seek(time - (e.shiftKey ? 5 : 1)); }
      else if (e.key === "Home") { e.preventDefault(); seek(0); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle, seek, time]);

  const active = clips.find((c) => time >= c.start && time < c.start + c.duration) || clips[clips.length - 1];
  const badClips = useMemo(
    () => new Set(clips.filter((c) => c.duration <= 0.0001).map((c) => c.name)),
    [clips]
  );
  const imageClips = useMemo(() => clips.filter((c) => !c.gap), [clips]);
  const imageCount = imageClips.length;
  const gapCount = clips.length - imageCount;
  const activeIndex = active && !active.gap ? imageClips.indexOf(active) + 1 : 0;

  const selectClip = useCallback((name) => {
    setSelectedCut(name);
    setCurrentType(transitionsByName[name] || "cut");
  }, [transitionsByName]);

  const pickType = useCallback((type) => {
    setCurrentType(type);
    if (selectedCut) setTransition(selectedCut, type);
  }, [selectedCut, setTransition]);

  const selectedClip = selectedCut && clips.find((c) => c.name === selectedCut);
  const selectedIndex = selectedClip ? clips.indexOf(selectedClip) : -1;
  const selectedImageNum = selectedClip && !selectedClip.gap ? imageClips.indexOf(selectedClip) + 1 : 0;

  return (
    <section className="editor">
      <div className="main">
        <div className="viewer">
          <div className="viewer__frame">
            <canvas ref={canvasRef} width={dims.width} height={dims.height} className="viewer__canvas" />
          </div>

          <div className="transport">
            <button className="play" onClick={toggle} aria-label={playing ? "Pause" : "Play"}>
              {playing ? "❚❚" : "►"}
            </button>
            <div className="time">
              <span className="time__now">{tc(time)}</span>
              <span className="time__sep">/</span>
              <span className="time__total">{tc(exportDuration)}</span>
            </div>
            <div className="transport__spacer" />
            <div className="history">
              <button
                className="hbtn" onClick={undo} disabled={!canUndo}
                title="Undo (Ctrl+Z)" aria-label="Undo"
              >↺</button>
              <button
                className="hbtn" onClick={redo} disabled={!canRedo}
                title="Redo (Ctrl+Shift+Z)" aria-label="Redo"
              >↻</button>
            </div>
            {active && (
              <div className="nowclip">
                <span className="nowclip__k">now</span>
                {active.gap ? "empty gap" : `image ${activeIndex} / ${imageCount}`}
              </div>
            )}
          </div>

          <audio ref={audioRef} src={audioUrl} hidden />
          <audio ref={musicRef} src={musicUrl || undefined} hidden loop preload="auto" />
        </div>

        {(() => {
          const shown = warnings.filter((w) => !dismissedWarn.has(w));
          if (!shown.length) return null;
          return (
            <div className="notes notes--compact">
              {shown.length > 1 && (
                <button
                  type="button" className="notes__clear"
                  onClick={() => setDismissedWarn(new Set(warnings))}
                >Dismiss all ({shown.length})</button>
              )}
              {shown.map((w) => (
                <div className="note note--dismissable" key={w}>
                  <span>{w}</span>
                  <button
                    type="button" className="note__x" aria-label="Dismiss"
                    onClick={() => setDismissedWarn((prev) => new Set(prev).add(w))}
                  >✕</button>
                </div>
              ))}
            </div>
          );
        })()}

        <Timeline
          clips={clips}
          imageEls={imageEls}
          duration={duration}
          time={time}
          peaks={peaks}
          activeName={active && active.name}
          badClips={badClips}
          transitionsByName={transitionsByName}
          motionByName={motionByName}
          selectedName={selectedCut}
          onSelect={selectClip}
          onSeek={seek}
          onScrubStart={onScrubStart}
          onScrubEnd={onScrubEnd}
          onOpen={openInspect}
          onAdd={askAdd}
          onResizeBoundary={resizeBoundary}
          trimEnd={trimEnd}
          onTrimChange={setTrimEnd}
        />
      </div>

      <aside className="side">
        <div className="panel export">
          <h2 className="panel__h">Export</h2>

          <div className="preset-row">
            {EXPORT_PRESETS.filter((p) => p.id !== "custom").map((p) => {
              const active = matchPreset(aspect, fps, renderQuality) === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  className={"preset-chip" + (active ? " is-on" : "")}
                  title={p.hint}
                  onClick={() => {
                    if (p.aspect) setAspect(p.aspect);
                    if (p.fps) setFps(p.fps);
                    if (p.quality && setRenderQuality) setRenderQuality(p.quality);
                  }}
                >
                  <span className="preset-chip__name">{p.label}</span>
                  <span className="preset-chip__hint">{p.hint}</span>
                </button>
              );
            })}
          </div>

          <div className="ctrl-row">
            <label className="ctrl">
              <span className="ctrl__label">Aspect</span>
              <span className="selectwrap">
                <select value={aspect} onChange={(e) => setAspect(e.target.value)}>
                  <option value="16:9">16:9 — 1920×1080</option>
                  <option value="9:16">9:16 — 1080×1920</option>
                  <option value="auto">Auto — match</option>
                </select>
              </span>
            </label>
            <label className="ctrl">
              <span className="ctrl__label">FPS</span>
              <span className="selectwrap">
                <select value={fps} onChange={(e) => setFps(+e.target.value)}>
                  <option value={24}>24 fps</option>
                  <option value={30}>30 fps</option>
                </select>
              </span>
            </label>
            <label className="ctrl">
              <span className="ctrl__label">Quality</span>
              <span className="selectwrap">
                <select value={renderQuality} onChange={(e) => setRenderQuality && setRenderQuality(e.target.value)}>
                  <option value="full">Full — {dims.width}×{dims.height}</option>
                  <option value="720p">720p — faster</option>
                </select>
              </span>
            </label>
          </div>

          <dl className="specs">
            <div className="spec"><dt>Resolution</dt><dd>{(renderDims || dims).width}×{(renderDims || dims).height}{renderQuality === "720p" ? " · faster" : ""}</dd></div>
            <div className="spec"><dt>Images</dt><dd>{imageCount}</dd></div>
            <div className="spec spec--length">
              <dt>Length</dt>
              <dd>
                {tc(exportDuration)}
                {exportDuration < duration && (
                  <span className="spec__trim">trimmed from {tc(duration)}</span>
                )}
              </dd>
            </div>
          </dl>

          {gapCount > 0 && (
            <div className="note note--gap">
              {gapCount} empty {gapCount === 1 ? "gap" : "gaps"} render black — fill with the <b>+</b>.
            </div>
          )}

          {/* Toggle only when BOTH paths exist (a render backend + WebCodecs).
              With no backend (e.g. Vercel) the app is WebCodecs-only, no toggle. */}
          {wcAvailable && serverAvailable && (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, marginBottom: 8, opacity: (busy || wcBusy) ? 0.5 : 1 }}>
              <span style={{ fontSize: 12.5, fontWeight: 600, opacity: 0.85 }}>⚡ Fast render</span>
              <button
                type="button"
                className={`cap-switch ${wcEnabled ? "is-on" : ""}`}
                onClick={() => setWcEnabled && setWcEnabled((v) => !v)}
                disabled={busy || wcBusy}
                aria-pressed={!!wcEnabled}
                aria-label="Fast GPU render (WebCodecs)"
                title="Render on the GPU via WebCodecs — faster for image-only projects (beta)"
              >
                <span className="cap-switch__box" />
              </button>
            </div>
          )}
          {!(busy || wcBusy) ? (
            (wcAvailable || serverAvailable) ? (
              <button
                className="render"
                onClick={(wcAvailable && (!serverAvailable || wcEnabled)) ? onWebCodecsTest : onRender}
              >Render MP4</button>
            ) : (
              <div className="note">Rendering needs Chrome, Edge, or Safari 16.4+ (WebCodecs) in this browser.</div>
            )
          ) : (
            <>
              <button className="render render--busy" disabled>
                {wcBusy ? (wcPhase || "Rendering") : "Rendering"}… {Math.round((wcBusy ? wcProgress : progress) * 100)}%
              </button>
              <div className="progress"><i style={{ width: `${Math.round((wcBusy ? wcProgress : progress) * 100)}%` }} /></div>
              <div className="render-meta">
                <span>{clock(elapsed)} elapsed</span>
                {(wcBusy ? wcProgress : progress) > 0.03 && <span>~{clock(elapsed * (1 - (wcBusy ? wcProgress : progress)) / (wcBusy ? wcProgress : progress))} left</span>}
              </div>
              <button className="cancel" onClick={wcBusy ? onWebCodecsCancel : onCancel}>Cancel</button>
            </>
          )}
          {outUrl && <a className="download" href={outUrl} download="story.mp4">↓ Download MP4</a>}
          {error && <div className="note note--bad">{error}</div>}
        </div>

        <div className="panel transitions">
          <div className="transitions__head">
            <div className="transitions__titlerow">
              <span className="panel__h">Transitions</span>
              <button
                type="button"
                className={`cap-switch ${mixMode ? "is-on" : ""}`}
                onClick={() => setMixMode((v) => !v)}
                aria-pressed={mixMode}
                title="Randomly apply a set of transitions across all cuts"
              >
                <span className="cap-switch__box" />
                Random mix
              </button>
            </div>
            <span className="transitions__target">
              {selectedIndex > 0
                ? `Into image ${selectedImageNum || "—"} · ${tc(selectedClip.start)}`
                : selectedIndex === 0
                  ? "First image — no incoming transition"
                  : "Tap a ◇ cut above to set its transition"}
            </span>
          </div>

          <div className="transitions__chips">
            {TRANSITION_LIST.map((tr) => {
              const on = mixMode ? mixPicks.has(tr.id) : currentType === tr.id;
              return (
                <button
                  key={tr.id}
                  type="button"
                  className={`trchip ${on ? "is-on" : ""}`}
                  onClick={() => (mixMode ? toggleMix(tr.id) : pickType(tr.id))}
                >
                  <span className="trchip__icon">{tr.icon}</span>{tr.label}
                </button>
              );
            })}
          </div>

          <label className="trdur">
            <span>Duration</span>
            <input
              type="range" min={MIN_TRANSITION_DURATION} max={MAX_TRANSITION_DURATION} step={0.05}
              value={transitionDuration}
              onChange={(e) => setTransitionDuration(+e.target.value)}
            />
            <span className="trdur__val">{transitionDuration.toFixed(2)}s</span>
          </label>

          {!mixMode ? (
            <button
              type="button" className="trall"
              onClick={() => applyTransitionAll(currentType, clips.map((c) => c.name))}
            >
              Apply “{transitionOf(currentType).label}” to all cuts
            </button>
          ) : (
            <div className="trmix-foot">
              <span className="trmix-count">
                {mixPicks.size ? `Picked ${mixPicks.size}` : "None picked"}
              </span>
              <button
                type="button" className="trall trmix-apply"
                disabled={mixPicks.size === 0}
                onClick={() => applyTransitionMix([...mixPicks], clips.map((c) => c.name))}
              >
                Apply random mix to video
              </button>
            </div>
          )}
        </div>

        <div className="panel">
          <h2 className="panel__h">Motion — Ken Burns zoom</h2>
          <div className="mini-h">Click an image on the timeline to set its zoom. Set the depth, or apply to all here.</div>
          <label className="trdur">
            <span>Zoom depth</span>
            <input type="range" min={0.02} max={0.2} step={0.01} value={motionAmount}
              onChange={(e) => setMotionAmount(+e.target.value)} />
            <span className="trdur__val">{Math.round(motionAmount * 100)}%</span>
          </label>
          <div className="seg" style={{ marginTop: 8 }}>
            <button type="button" onClick={() => applyMotionAll("zoomin", imageClips.map((c) => c.name))}>Zoom in all</button>
            <button type="button" onClick={() => applyMotionAll("zoomout", imageClips.map((c) => c.name))}>Zoom out all</button>
          </div>
          <div className="seg" style={{ marginTop: 6 }}>
            <button type="button" onClick={() => applyMotionAlternate(imageClips.map((c) => c.name))}>Alternate</button>
            <button type="button" onClick={() => applyMotionAll("none", imageClips.map((c) => c.name))}>Clear</button>
          </div>
        </div>

        <div className="panel">
          <h2 className="panel__h">Scene fades</h2>
          <div className="mini-h">Fade the opening and ending (video &amp; audio).</div>
          <label className="trdur">
            <span>Fade in</span>
            <input type="range" min={0} max={2} step={0.1} value={fadeIn} onChange={(e) => setFadeIn(+e.target.value)} />
            <span className="trdur__val">{fadeIn > 0 ? `${fadeIn.toFixed(1)}s` : "off"}</span>
          </label>
          <label className="trdur">
            <span>Fade out</span>
            <input type="range" min={0} max={2} step={0.1} value={fadeOut} onChange={(e) => setFadeOut(+e.target.value)} />
            <span className="trdur__val">{fadeOut > 0 ? `${fadeOut.toFixed(1)}s` : "off"}</span>
          </label>
        </div>

        <div className="panel captions">
          <h2 className="panel__h">Captions</h2>
          {!(captionCues && captionCues.length) ? (
            <div className="cap-empty">
              <button type="button" className="cap-upload" onClick={() => capInputRef.current && capInputRef.current.click()}>
                <span className="cap-upload__i">⤒</span> Upload timestamped script
              </button>
              <p className="cap-hint">
                An <code>.srt</code>, <code>.vtt</code>, or timestamped <code>.txt</code> — inline
                markers like <code>(0:03)</code>, NoteGPT ranges, or <code>[0:03]</code> lines all
                work. Captions sync to the audio and burn into the MP4.
              </p>
              {captionError && <div className="note note--bad">{captionError}</div>}
            </div>
          ) : (
            <>
              <div className="cap-bar">
                <button
                  type="button"
                  className={`cap-switch ${captionsOn ? "is-on" : ""}`}
                  onClick={() => setCaptionsOn(!captionsOn)}
                  aria-pressed={captionsOn}
                >
                  <span className="cap-switch__box" />
                  {captionsOn ? "On" : "Off"}
                </button>
                <span className="cap-meta">
                  <span className="cap-meta__name">{captionName || "captions"}</span>
                  {captionCues.length} lines ·{" "}
                  <button type="button" className="cap-replace" onClick={() => capInputRef.current && capInputRef.current.click()}>replace</button>
                </span>
              </div>

              <div className="cap-body" aria-disabled={!captionsOn}>
                <div className="mini-h">Style</div>
                <div className="transitions__chips">
                  {CAPTION_STYLE_LIST.map((st) => (
                    <button
                      key={st.id}
                      type="button"
                      className={`trchip ${captionStyle === st.id ? "is-on" : ""}`}
                      onClick={() => setCaptionStyle(st.id)}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>

                <div className="mini-h" style={{ marginTop: 12 }}>Font</div>
                <div className="transitions__chips">
                  {CAPTION_FONT_LIST.map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      className={`trchip ${captionFont === f.id ? "is-on" : ""}`}
                      style={{ fontFamily: f.css }}
                      onClick={() => setCaptionFont && setCaptionFont(f.id)}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>

                <div className="mini-h" style={{ marginTop: 12 }}>Animate in</div>
                <div className="transitions__chips">
                  {CAPTION_ANIM_LIST.map((an) => (
                    <button
                      key={an.id}
                      type="button"
                      className={`trchip ${captionAnim === an.id ? "is-on" : ""}`}
                      onClick={() => setCaptionAnim && setCaptionAnim(an.id)}
                    >
                      {an.label}
                    </button>
                  ))}
                </div>

                <div className="mini-h" style={{ marginTop: 12 }}>Size</div>
                <div className="seg">
                  {[["sm", "Small"], ["md", "Medium"], ["lg", "Large"]].map(([id, lbl]) => (
                    <button
                      key={id}
                      type="button"
                      className={captionFontScale == null && captionSize === id ? "is-on" : ""}
                      onClick={() => { setCaptionSize(id); setCaptionFontScale && setCaptionFontScale(null); }}
                    >{lbl}</button>
                  ))}
                </div>

                <div className="mini-h" style={{ marginTop: 12 }}>Font size (fine-tune)</div>
                <label className="trdur">
                  <input
                    type="range" min={0.03} max={0.10} step={0.002}
                    value={captionFontScale != null ? captionFontScale : (CAPTION_SIZES[captionSize] || CAPTION_SIZES.md)}
                    onChange={(e) => setCaptionFontScale && setCaptionFontScale(+e.target.value)}
                  />
                  <span className="trdur__val">
                    {Math.round((captionFontScale != null ? captionFontScale : (CAPTION_SIZES[captionSize] || CAPTION_SIZES.md)) * 1000) / 10}%
                  </span>
                </label>
                {captionFontScale != null && (
                  <button type="button" className="cap-replace" onClick={() => setCaptionFontScale && setCaptionFontScale(null)}>
                    reset to preset
                  </button>
                )}

                <div className="mini-h" style={{ marginTop: 12 }}>Line spacing (2-line captions)</div>
                <label className="trdur">
                  <input
                    type="range" min={1.0} max={2.2} step={0.05}
                    value={captionLineHeight != null ? captionLineHeight : captionLineHeightDefault(captionStyle)}
                    onChange={(e) => setCaptionLineHeight && setCaptionLineHeight(+e.target.value)}
                  />
                  <span className="trdur__val">
                    {(captionLineHeight != null ? captionLineHeight : captionLineHeightDefault(captionStyle)).toFixed(2)}×
                  </span>
                </label>
                {captionLineHeight != null && (
                  <button type="button" className="cap-replace" onClick={() => setCaptionLineHeight && setCaptionLineHeight(null)}>
                    reset to default
                  </button>
                )}
              </div>
              {captionError && <div className="note note--bad">{captionError}</div>}
            </>
          )}
        </div>

        <div className="panel music-panel">
          <h2 className="panel__h">Background music</h2>
          {!musicFile ? (
            <div className="cap-empty">
              <button type="button" className="cap-upload" onClick={() => musicInputRef.current && musicInputRef.current.click()}>
                <span className="cap-upload__i">♫</span> Add music track
              </button>
              <p className="cap-hint">
                An MP3, WAV, or other audio file. It plays <strong>under</strong> your voiceover —
                looped to fit the video and faded out at the end.
              </p>
            </div>
          ) : (
            <>
              <div className="cap-bar">
                <span className="cap-meta">
                  <span className="cap-meta__name">{musicFile.name}</span>
                  <button type="button" className="cap-replace" onClick={() => musicInputRef.current && musicInputRef.current.click()}>replace</button>
                  {" · "}
                  <button type="button" className="cap-replace" onClick={() => clearMusic && clearMusic()}>remove</button>
                </span>
              </div>
              <div className="cap-body">
                <div className="mini-h">Music volume</div>
                <label className="trdur">
                  <input
                    type="range" min={0} max={0.6} step={0.01}
                    value={musicVolume}
                    onChange={(e) => setMusicVolume && setMusicVolume(+e.target.value)}
                  />
                  <span className="trdur__val">{Math.round(musicVolume * 100)}%</span>
                </label>

                <label className="music-duck" style={{ marginTop: 12 }}>
                  <input
                    type="checkbox" checked={musicDuck}
                    onChange={(e) => setMusicDuck && setMusicDuck(e.target.checked)}
                  />
                  <span>Lower music while voiceover plays (recommended)</span>
                </label>
              </div>
            </>
          )}
        </div>

        <div className="panel logo-panel">
          <h2 className="panel__h">Logo / watermark</h2>
          {!logoFile ? (
            <div className="cap-empty">
              <button type="button" className="cap-upload" onClick={() => logoInputRef.current && logoInputRef.current.click()}>
                <span className="cap-upload__i">▣</span> Add logo image
              </button>
              <p className="cap-hint">
                A PNG (transparent background works best) or any image. It's placed in a
                corner of every frame and burned into the export.
              </p>
            </div>
          ) : (
            <>
              <div className="cap-bar">
                {logoImg && <img className="logo-preview" src={logoImg.url} alt="" />}
                <span className="cap-meta">
                  <span className="cap-meta__name">{logoFile.name}</span>
                  <button type="button" className="cap-replace" onClick={() => logoInputRef.current && logoInputRef.current.click()}>replace</button>
                  {" · "}
                  <button type="button" className="cap-replace" onClick={() => clearLogo && clearLogo()}>remove</button>
                </span>
              </div>
              <div className="cap-body">
                <div className="mini-h">Position</div>
                <div className="transitions__chips">
                  {LOGO_POSITION_LIST.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      className={`trchip ${logoPosition === p.id ? "is-on" : ""}`}
                      onClick={() => setLogoPosition && setLogoPosition(p.id)}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>

                <div className="mini-h" style={{ marginTop: 12 }}>Size</div>
                <label className="trdur">
                  <input
                    type="range" min={0.05} max={0.4} step={0.01}
                    value={logoSize}
                    onChange={(e) => setLogoSize && setLogoSize(+e.target.value)}
                  />
                  <span className="trdur__val">{Math.round(logoSize * 100)}%</span>
                </label>

                <div className="mini-h" style={{ marginTop: 12 }}>Opacity</div>
                <label className="trdur">
                  <input
                    type="range" min={0.1} max={1} step={0.05}
                    value={logoOpacity}
                    onChange={(e) => setLogoOpacity && setLogoOpacity(+e.target.value)}
                  />
                  <span className="trdur__val">{Math.round(logoOpacity * 100)}%</span>
                </label>
              </div>
            </>
          )}
        </div>

        <div className="panel effects-panel">
          <h2 className="panel__h">Cinematic effects</h2>
          <div className="cap-body">
            <div className="mini-h">Vignette</div>
            <label className="trdur">
              <input type="range" min={0} max={1} step={0.05} value={vignette}
                onChange={(e) => setVignette && setVignette(+e.target.value)} />
              <span className="trdur__val">{Math.round(vignette * 100)}%</span>
            </label>

            <div className="mini-h" style={{ marginTop: 12 }}>Film grain</div>
            <label className="trdur">
              <input type="range" min={0} max={1} step={0.05} value={grain}
                onChange={(e) => setGrain && setGrain(+e.target.value)} />
              <span className="trdur__val">{Math.round(grain * 100)}%</span>
            </label>

            <div className="mini-h" style={{ marginTop: 12 }}>Light leaks</div>
            <label className="trdur">
              <input type="range" min={0} max={1} step={0.05} value={leaks}
                onChange={(e) => setLeaks && setLeaks(+e.target.value)} />
              <span className="trdur__val">{Math.round(leaks * 100)}%</span>
            </label>
            <p className="cap-hint" style={{ marginTop: 10 }}>
              Subtle looks that read as cinematic. Grain &amp; light leaks animate over time.
            </p>
          </div>
        </div>

      </aside>

      <input
        ref={fileInputRef} type="file" accept={coarse ? undefined : "image/*,video/*"} hidden
        onChange={onPickFile}
      />
      <input
        ref={replaceInputRef} type="file" accept={coarse ? undefined : "image/*,video/*"} hidden
        onChange={onPickReplacement}
      />
      <input
        ref={capInputRef} type="file" accept=".srt,.vtt,.txt,text/plain" hidden
        onChange={onPickCaption}
      />
      <input
        ref={musicInputRef} type="file" accept="audio/*" hidden
        onChange={onPickMusic}
      />
      <input
        ref={logoInputRef} type="file" accept="image/*" hidden
        onChange={onPickLogo}
      />

      {inspect && (() => {
        const insClip = clips.find((c) => c.name === inspect);
        const el = imageEls[inspect];
        const num = insClip ? imageClips.indexOf(insClip) + 1 : 0;
        const curUrl = pendUrl || (el && el.url);
        const pendIsVid = !!(pendFile && pendFile.type && pendFile.type.startsWith("video/"));
        const isVid = !!(el && el.isVideo) && !pendUrl;
        const vinfo = videoInfoByName[inspect] || {};
        const vol = volumeByName[inspect] == null ? 0.5 : volumeByName[inspect];
        const inPt = trimByName[inspect] || 0;
        const kind = isVid ? "Video" : "Image";
        const slotDur = (insClip && insClip.duration) || 0;
        const vdur = vinfo.duration || 0;
        const longer = !!(vdur && insClip && vdur > slotDur + 0.05);
        const shorter = !!(vdur && insClip && vdur < slotDur - 0.05);
        const diff = longer || shorter;
        // Default by length: longer clip trims (1x), shorter fills the slot (fit/slow).
        const fitMode = fitByName[inspect] || (longer ? "trim" : "fit");
        const speed = (diff && slotDur > 0) ? (vdur / slotDur) : 1;
        return (
          <div className="modal" role="dialog" aria-modal="true" onClick={closeInspect}>
            <div className="modal__card" onClick={(e) => e.stopPropagation()}>
              <div className="modal__head">
                <span className="modal__title">
                  {num ? `${kind} ${num} of ${imageCount}` : kind}
                  {insClip && <span className="modal__at"> · {tc(insClip.start)}</span>}
                </span>
                <button className="modal__x" onClick={closeInspect} aria-label="Close">✕</button>
              </div>

              <div className="modal__stage">
                {pendUrl ? (
                  // A chosen-but-not-applied replacement: a video needs a <video>,
                  // not an <img> (an <img> with a video URL just shows black).
                  pendIsVid
                    ? <video src={pendUrl} className="modal__stagevid" controls muted playsInline preload="metadata" />
                    : <img src={pendUrl} alt="" />
                ) : isVid && vinfo.url ? (
                  <video
                    ref={modalVideoRef} src={vinfo.url} className="modal__stagevid"
                    controls muted playsInline preload="metadata"
                    onLoadedMetadata={(e) => {
                      const v = e.currentTarget;
                      try { v.currentTime = inPt; } catch { /* ignore */ }
                      v.playbackRate = (diff && fitMode === "fit") ? Math.min(16, Math.max(0.0625, speed)) : 1;
                    }}
                  />
                ) : (curUrl && <img src={curUrl} alt="" />)}
                {pendUrl && <span className="modal__flag">New — not applied yet</span>}
              </div>
              <div className="modal__file">
                {pendFile ? pendFile.name : (el && el.fileName) || ""}
              </div>

              {insClip && !insClip.gap && (
                <div className="modal__motion">
                  <span className="modal__motion-label">Motion preset</span>
                  <div className="seg seg--wrap">
                    {MOTION_LIST.map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        className={((motionByName && motionByName[inspect]) || "none") === m.id ? "is-on" : ""}
                        onClick={() => setMotion && setMotion(inspect, m.id)}
                      >{m.label}</button>
                    ))}
                  </div>
                </div>
              )}

              {insClip && !insClip.gap && isVid && (
                <div className="modal__vid">
                  {diff && (
                    <div className="modal__fit">
                      <span className="modal__motion-label">
                        {longer ? "Clip is longer than its slot" : "Clip is shorter than its slot"} · {vinfo.duration.toFixed(1)}s clip, {insClip.duration.toFixed(1)}s slot
                      </span>
                      <div className="seg">
                        <button
                          type="button" className={fitMode === "fit" ? "is-on" : ""}
                          onClick={() => setFit && setFit(inspect, "fit")}
                        >Fit to slot</button>
                        <button
                          type="button" className={fitMode === "trim" ? "is-on" : ""}
                          onClick={() => setFit && setFit(inspect, "trim")}
                        >Trim (1×)</button>
                      </div>
                      {fitMode === "fit"
                        ? <span className="modal__hint">{longer
                            ? `Whole clip fast-forwarded at ${speed.toFixed(1)}× to fit the slot.`
                            : `Whole clip slowed to ${speed.toFixed(2)}× to fill the slot.`}</span>
                        : <span className="modal__hint">Plays at 1× — set a start point below;{longer ? " the rest is cut off." : " the last frame then holds to fill the slot."}</span>}
                    </div>
                  )}
                  {(!diff || fitMode === "trim") && (() => {
                    const dur = vinfo.duration || 0;
                    const remain = Math.max(0, dur - inPt);        // footage left from the start point
                    const playLen = Math.min(insClip.duration, remain); // real-time footage shown
                    const holdFor = Math.max(0, insClip.duration - remain); // seconds the last frame holds
                    return (
                      <div className="modal__trim">
                        <span className="modal__motion-label">Trim — drag the handle to set where the clip starts</span>
                        {/* Video-editor style trim bar: the fill shows the part that plays;
                            dragging the handle scrubs the preview above and sets the start. */}
                        <div className="trimbar">
                          <div
                            className="trimbar__fill"
                            style={{ left: `${dur ? (inPt / dur) * 100 : 0}%`, width: `${dur ? (playLen / dur) * 100 : 0}%` }}
                          />
                          <input
                            className="trimbar__range"
                            type="range" min={0} max={Math.max(0.1, dur)} step={0.05}
                            value={Math.min(inPt, Math.max(0.1, dur))}
                            onChange={(e) => {
                              const val = +e.target.value;
                              if (setTrim) setTrim(inspect, val);
                              if (modalVideoRef.current) { try { modalVideoRef.current.currentTime = val; } catch { /* ignore */ } }
                            }}
                          />
                        </div>
                        <span className="modal__hint">
                          Starts at {inPt.toFixed(1)}s of {dur.toFixed(1)}s · plays {playLen.toFixed(1)}s in a {insClip.duration.toFixed(1)}s slot
                        </span>
                        {holdFor > 0.05 && (
                          <span className="modal__hint modal__hint--warn">
                            Only {remain.toFixed(1)}s of footage left — the last frame holds for {holdFor.toFixed(1)}s to fill the slot.
                          </span>
                        )}
                      </div>
                    );
                  })()}
                  <div className="modal__vol">
                    <span className="modal__motion-label">Clip audio volume</span>
                    <div className="modal__slider">
                      <input
                        type="range" min={0} max={1} step={0.05} value={vol}
                        onChange={(e) => setVolume && setVolume(inspect, +e.target.value)}
                      />
                      <span className="trdur__val">{Math.round(vol * 100)}%</span>
                    </div>
                    <span className="modal__hint">Plays under the voiceover. 0% = silent.</span>
                  </div>
                </div>
              )}

              {!pendUrl ? (
                <div className="modal__actions">
                  <button className="mbtn mbtn--primary" onClick={() => replaceInputRef.current && replaceInputRef.current.click()}>
                    Replace {isVid ? "video" : "image"}
                  </button>
                  <button className="mbtn mbtn--danger" onClick={removeInspected}>Remove from timeline</button>
                </div>
              ) : (
                <div className="modal__actions">
                  <button className="mbtn mbtn--primary" onClick={applyReplacement}>Apply replacement</button>
                  <button className="mbtn" onClick={() => replaceInputRef.current && replaceInputRef.current.click()}>Choose different</button>
                  <button className="mbtn mbtn--ghost" onClick={clearPend}>Cancel</button>
                </div>
              )}
            </div>
          </div>
        );
      })()}
    </section>
  );
}
